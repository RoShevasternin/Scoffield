package com.plinkray.ioosudmarine.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("5C01D3")
}