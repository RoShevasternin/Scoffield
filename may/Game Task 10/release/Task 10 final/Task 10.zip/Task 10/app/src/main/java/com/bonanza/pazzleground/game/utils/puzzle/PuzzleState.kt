package com.bonanza.pazzleground.game.utils.puzzle

enum class PuzzleState {
    ASSEMBLED, NOT_ASSEMBLED
}