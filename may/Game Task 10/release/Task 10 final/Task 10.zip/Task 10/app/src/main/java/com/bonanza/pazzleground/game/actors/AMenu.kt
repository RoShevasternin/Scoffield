package com.bonanza.pazzleground.game.actors

import com.bonanza.pazzleground.game.utils.advanced.AdvancedGroup
import com.bonanza.pazzleground.game.utils.advanced.AdvancedScreen

class AMenu(
    override val screen: AdvancedScreen,
): AdvancedGroup() {

    //private val btnHome = AButton(screen, AButton.Type.Home)

    override fun addActorsOnGroup() {
        //addAndFillActor(imgPanel)
    }

}