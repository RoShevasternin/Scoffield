package com.plinki.kollinllabs.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("4C007E")
}