package com.treasurebig.twins.game.utils

const val WIDTH_UI  = 2000f
const val HEIGHT_UI = 1200f

const val TIME_ANIM_SCREEN = 0.075f