package com.order.offortute.game.utils

import com.badlogic.gdx.graphics.Color

object GameColor {

    val background: Color = Color.valueOf("000000")

    val gold: Color = Color.valueOf("FAFF9A")

}