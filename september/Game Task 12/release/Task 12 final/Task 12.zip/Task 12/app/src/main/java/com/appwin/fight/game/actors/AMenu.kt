package com.appwin.fight.game.actors

import com.appwin.fight.game.utils.advanced.AdvancedGroup
import com.appwin.fight.game.utils.advanced.AdvancedScreen

class AMenu(
    override val screen: AdvancedScreen,
): AdvancedGroup() {

    //private val btnHome = AButton(screen, AButton.Type.Home)

    override fun addActorsOnGroup() {
        //addAndFillActor(imgPanel)
    }

}