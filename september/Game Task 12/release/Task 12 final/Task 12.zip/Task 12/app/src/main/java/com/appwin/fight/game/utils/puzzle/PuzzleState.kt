package com.appwin.fight.game.utils.puzzle

enum class PuzzleState {
    ASSEMBLED, NOT_ASSEMBLED
}