package com.beeand.honeybonanza.game.box2d

object BodyId {
    const val NONE    = "none"
    const val BORDERS = "borders"

    const val BEE   = "bird"
    const val HONEY = "win"
    const val DOWN  = "down"

}