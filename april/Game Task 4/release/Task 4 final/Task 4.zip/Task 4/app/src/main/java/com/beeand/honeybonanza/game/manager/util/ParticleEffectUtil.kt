package com.beeand.honeybonanza.game.manager.util

import com.beeand.honeybonanza.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val BEE = ParticleEffectManager.EnumParticleEffect.BEE.data.effect
    val MED = ParticleEffectManager.EnumParticleEffect.MED.data.effect

}

