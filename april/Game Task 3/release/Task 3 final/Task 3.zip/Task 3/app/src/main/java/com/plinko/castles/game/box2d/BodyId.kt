package com.plinko.castles.game.box2d

object BodyId {
    const val NONE    = "none"
    const val BORDERS = "borders"

    const val STONE  = "stone"
    const val CASTLE = "castle"

}