package com.plinko.castles.game.manager.util

import com.plinko.castles.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val dwm = ParticleEffectManager.EnumParticleEffect.dwm.data.effect

}

