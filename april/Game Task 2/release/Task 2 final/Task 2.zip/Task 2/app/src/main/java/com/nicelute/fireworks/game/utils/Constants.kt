package com.nicelute.fireworks.game.utils

const val WIDTH_UI  = 1080f
const val HEIGHT_UI = 1920f