package com.plinko.x10balls.game.manager.util

import com.plinko.x10balls.game.manager.ParticleEffectManager

class ParticleEffectUtil {

    val BOOM   = ParticleEffectManager.EnumParticleEffect.BOOM.data.effect
    val ROCKET = ParticleEffectManager.EnumParticleEffect.ROCKET.data.effect

}

