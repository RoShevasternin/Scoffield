package com.plinko.x10balls.game.box2d

object BodyId {
    const val NONE = "none"

    const val ROCKET   = "rocket"
    const val ASTEROID = "asteroid"
    const val WHEEL    = "wheel"
}