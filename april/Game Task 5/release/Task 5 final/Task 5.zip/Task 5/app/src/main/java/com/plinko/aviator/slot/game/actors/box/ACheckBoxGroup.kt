package com.plinko.aviator.slot.game.actors.box

class ACheckBoxGroup {
    var currentCheckedCheckBox: ACheckBox? = null
}