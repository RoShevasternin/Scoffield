package com.plinko.x10balls.game.manager

import com.badlogic.gdx.Gdx
import com.plinko.x10balls.game.LibGDXGame
import com.plinko.x10balls.game.screens.StarGameScreen
import com.plinko.x10balls.game.screens.StarLoaderScreen
import com.plinko.x10balls.game.utils.advanced.AdvancedScreen
import com.plinko.x10balls.game.utils.runGDX

class NavigationManager(val game: LibGDXGame) {

    private val backStack = mutableListOf<String>()
    var key: Int? = null
        private set

    fun navigate(toScreenName: String, fromScreenName: String? = null, key: Int? = null) = runGDX {
        this.key = key

        game.updateScreen(getScreenByName(toScreenName))
        backStack.filter { name -> name == toScreenName }.onEach { name -> backStack.remove(name) }
        fromScreenName?.let { fromName ->
            backStack.filter { name -> name == fromName }.onEach { name -> backStack.remove(name) }
            backStack.add(fromName)
        }
    }

    fun back(key: Int? = null) = runGDX {
        this.key = key

        if (isBackStackEmpty()) exit() else game.updateScreen(getScreenByName(backStack.removeAt(backStack.lastIndex)))
    }


    fun exit() = runGDX { Gdx.app.exit() }


    fun isBackStackEmpty() = backStack.isEmpty()

    private fun getScreenByName(name: String): AdvancedScreen = when(name) {
        StarLoaderScreen::class.java.name -> StarLoaderScreen(game)
        StarGameScreen  ::class.java.name -> StarGameScreen(game)

        else                                 -> StarLoaderScreen(game)
    }

}


